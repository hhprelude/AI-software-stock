# AI 상대강도 대시보드 — 미국장 마감 후 자동 갱신판

## 제공 기능
- 3개 ETF: IGV(소프트웨어), SMH(반도체), SPY(미국 대형주)
- 개별주 19개: 소프트웨어 13개 / 하드웨어 6개
- 매 미국 거래일 종료 후 다음 날 **한국시간 오전 9시 37분경** 데이터 수집 작업 시작 (GitHub Actions 작업 시작/게시 지연 가능)
- 일간 분할·배당 조정 종가로 **약 1·3·6개월 수익률, 업종·시장 대비 초과수익, 자체 상대강도 점수 및 순위** 재계산
- 부정확하거나 오래된 가격 데이터면 갱신을 중단하고 직전 성공 자료 유지
- 모든 브라우저 기기에서 동일한 공개 URL 접속 가능

**중요:** 가격 및 상대강도만 자동 갱신됩니다. 기업별 최신 실적 수치, 기업 설명, 밸류에이션, 거시경제 데이터는 자동 수집하지 않습니다. 기존 HTML에 보관된 기업 설명은 주기적으로 직접 확인해야 합니다.

## 최초 설정 (GitHub 계정 필요)
1. 압축을 해제합니다. `.github` 폴더가 숨겨지지 않았는지 확인하세요.
2. GitHub에서 **Public** 저장소를 새로 만듭니다. 예: `ai-relative-strength` (기본 브랜치 이름 `main`). 공개 사이트이므로 개인 계좌·거래내역·비밀번호를 절대 올리지 마세요.
3. 압축을 푼 폴더의 **내용물 전체**(`index.html`, `update_prices.py`, `requirements.txt`, `data/`, `.github/`)를 저장소에 업로드합니다. GitHub Desktop으로 게시하거나 웹 업로드 시 `.github/workflows/daily.yml` 경로가 유지되는지 확인하세요. ZIP 파일 하나만 올리면 실행되지 않습니다.
4. 저장소 **Settings → Pages → Build and deployment → Source → GitHub Actions**로 설정합니다.
5. 저장소 **Actions → AI RS daily prices and dashboard → Run workflow**를 눌러 초기 실행합니다. 처음 가격 수집·배포가 성공해야 최신 데이터가 나타납니다.
6. **Settings → Pages**에 표시된 웹주소를 열면 됩니다. 일반적으로 `https://<사용자ID>.github.io/<저장소이름>/` 형식입니다.
7. 이후 미국 주식시장이 열린 날이면 다음 한국시간 오전에 자동 가격 데이터가 갱신됩니다. 실행 시각은 보장된 실시간 시각이 아닙니다.

## 데이터를 수동으로 갱신하는 방법
- GitHub 저장소 **Actions → AI RS daily prices and dashboard → Run workflow**
- 또는 PC에서 `python -m pip install -r requirements.txt` 이후 `python update_prices.py` 실행.
- 로컬 HTML은 같은 폴더에 CSV를 저장해도 브라우저의 `file://` 보안 제한으로 자동 불러오지 않습니다. 로컬 파일에서는 화면의 **가격 CSV 업로드**를 이용하세요. GitHub Pages 주소에서는 자동 불러옵니다.

## 자동 갱신이 안 될 때
- Actions 실행 기록에서 `Download prices and validate completeness` 단계 확인.
- Yahoo Finance 비공식 피드가 차단/지연되면 실패할 수 있습니다. 실패한 날에는 이전 성공 시점의 시세가 남으며, 화면의 '마지막 거래일'로 판단할 수 있습니다.
- GitHub Actions 예약 실행은 지연/누락될 수 있습니다. 또한 GitHub 공용 저장소에서 **60일간 활동이 없으면** 예약 작업이 비활성화될 수 있습니다. 최신 자료를 저장소에 매일 커밋하도록 구현했지만 업데이트가 장기간 멈추면 확인이 필요합니다.
- 최초 게시가 안 되면 Pages의 Source가 GitHub Actions인지 확인하고 Actions에서 수동 실행하세요.
- `main`이 아닌 다른 이름의 기본 브랜치를 사용할 경우 `.github/workflows/daily.yml`의 `branches` 및 `git push ... HEAD:main`을 수정해야 합니다.

## 주의사항
- 시세는 **실시간이 아니라 미국 거래소 종가 기반의 일별 데이터**입니다. 장중 가격/호가/주문 데이터는 포함하지 않습니다.
- 조정종가(배당·분할 조정치)는 실제 거래 시 체결가격과 다릅니다. Yahoo Finance/yfinance 자료는 공식 거래소 데이터가 아니며 서비스 정책, 사용허가, API 변경, 지연 및 오류에 영향을 받습니다. 대외 재배포 또는 상업적 이용은 별도의 데이터 라이선스를 확인하세요.
- 자체 상대강도 점수는 연구용 순위 지표이며 향후 수익률 예측 또는 매수·매도 추천이 아닙니다.
